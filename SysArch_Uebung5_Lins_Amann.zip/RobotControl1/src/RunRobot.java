
public class RunRobot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PushBallBangBangController ctrl = new PushBallBangBangController();
//		ctrl.robStart();
		
	}

}
