to start controller a
	--> open simulator and load balls map file
	--> start Controller "PushBallsToWallController"

to start controller b
	--> open simulator and load ballsAndLight map file
	--> start Controller "PushBallsToLightController"